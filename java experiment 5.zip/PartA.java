import java.util.*;
public class PartA {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Integer> list = new ArrayList<>();
        for(int i =0; i<3; i++){
            System.out.println("Please enter the number of index: "+ i);
            int num = sc.nextInt();
            list.add(num); //autoboxing
        }
        int sum = 0;
        for(Integer ele : list){
            sum+= ele; // unboxing

        }
        System.out.println(sum);
        
    }

}
